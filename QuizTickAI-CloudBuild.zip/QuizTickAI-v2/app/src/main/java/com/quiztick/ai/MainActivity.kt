package com.quiztick.ai

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        root.addView(TextView(this).apply {
            text = "Quiz Tick AI"
            textSize = 28f
        })

        root.addView(TextView(this).apply {
            text = "Fast MCQ helper: reads the current quiz screen and puts a green ✓ beside the selected answer."
            textSize = 16f
            setPadding(0, 12, 0, 20)
        })

        apiKey = EditText(this).apply {
            hint = "Gemini API key"
            inputType = 0x00000081
            setText(getSharedPreferences("quiztick", MODE_PRIVATE).getString("key", ""))
        }
        root.addView(apiKey)

        model = EditText(this).apply {
            hint = "Model"
            setText(getSharedPreferences("quiztick", MODE_PRIVATE).getString("model", "gemini-2.5-flash-lite"))
        }
        root.addView(model)

        val save = Button(this).apply { text = "Save settings" }
        root.addView(save)

        val accessibility = Button(this).apply { text = "Open Accessibility settings" }
        root.addView(accessibility)

        val start = Button(this).apply { text = "Start / refresh assistant" }
        root.addView(start)

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 20, 0, 0)
        }
        root.addView(status)

        save.setOnClickListener {
            getSharedPreferences("quiztick", MODE_PRIVATE).edit()
                .putString("key", apiKey.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .apply()
            status.text = "Saved. Enable the Accessibility service, then open your quiz."
        }

        accessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        start.setOnClickListener {
            QuizAccessibilityService.instance?.requestImmediateScan()
            status.text = if (QuizAccessibilityService.instance != null)
                "Assistant is active."
            else
                "Service is not active. Enable it in Accessibility settings."
        }

        setContentView(root)
    }
}
