package com.quiztick.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max

class QuizAccessibilityService : AccessibilityService() {

    companion object {
        var instance: QuizAccessibilityService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val busy = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())

    private var lastFingerprint = ""
    private var tickView: TextView? = null
    private var tickParams: WindowManager.LayoutParams? = null
    private var windowManager: WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityServiceInfo.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityServiceInfo.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityServiceInfo.TYPE_VIEW_SCROLLED
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        scheduleScan(350)
    }

    override fun onDestroy() {
        instance = null
        removeTick()
        scope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (event == null) return
        scheduleScan(250)
    }

    override fun onInterrupt() {}

    fun requestImmediateScan() {
        scheduleScan(0)
    }

    private fun scheduleScan(delay: Long) {
        handler.removeCallbacksAndMessages("scan")
        handler.postAtTime({
            if (!busy.get()) scan()
        }, "scan", android.os.SystemClock.uptimeMillis() + delay)
    }

    private fun scan() {
        if (!busy.compareAndSet(false, true)) return

        // First try the accessibility tree: this is normally faster than OCR.
        val tree = extractAccessibilityText()
        if (tree.options.size >= 4 && tree.question.length >= 3) {
            val fp = tree.question + "|" + tree.options.joinToString("|")
            if (fp == lastFingerprint) {
                busy.set(false)
                return
            }
            lastFingerprint = fp
            scope.launch {
                val answer = GeminiClient.answerText(
                    apiKey = getPrefs("key"),
                    model = getPrefs("model", "gemini-2.5-flash-lite"),
                    question = tree.question,
                    options = tree.options
                )
                withContext(Dispatchers.Main) {
                    if (answer in 0..3 && tree.bounds.size >= 4) {
                        showTick(tree.bounds[answer])
                    } else {
                        removeTick()
                    }
                    busy.set(false)
                }
            }
            return
        }

        // Fallback: screenshot + on-device OCR.
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val bitmap = try {
                    Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                } catch (_: Throwable) { null }

                if (bitmap == null) {
                    busy.set(false)
                    return
                }

                val copy = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                bitmap.recycle()
                runOcr(copy)
            }

            override fun onFailure(errorCode: Int) {
                busy.set(false)
            }
        })
    }

    private data class TreeResult(
        val question: String,
        val options: List<String>,
        val bounds: List<Rect>
    )

    private fun extractAccessibilityText(): TreeResult {
        val root = rootInActiveWindow ?: return TreeResult("", emptyList(), emptyList())
        val texts = mutableListOf<Pair<String, Rect>>()

        fun walk(node: android.view.accessibility.AccessibilityNodeInfo?) {
            if (node == null) return
            val text = node.text?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (!r.isEmpty) texts.add(text to r)
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)

        val candidates = texts.filter { (t, r) ->
            r.height() > 25 && r.width() > 250 && t.length < 250
        }.sortedBy { it.second.top }

        val optionMatches = candidates.filter {
            Regex("""^\s*(?:[A-Da-d][\.\)\-:]\s*|\d[\.\)\-:]\s*)""").containsMatchIn(it.first)
        }.take(4)

        if (optionMatches.size == 4) {
            val questionParts = candidates.filter { it.second.bottom < optionMatches.first().second.top }
                .map { it.first }
                .filter { it.length > 3 }
            return TreeResult(
                questionParts.joinToString(" "),
                optionMatches.map { it.first },
                optionMatches.map { it.second }
            )
        }

        // Generic fallback for unlabeled buttons: four large vertically stacked nodes.
        val grouped = candidates.filter { it.second.top < resources.displayMetrics.heightPixels * 0.95 }
        val four = grouped.takeLast(4)
        if (four.size == 4 && four.zipWithNext().all { it.second.second.top > it.first.second.top }) {
            val questionParts = grouped.dropLast(4).map { it.first }.filter { it.length > 3 }
            return TreeResult(questionParts.joinToString(" "), four.map { it.first }, four.map { it.second })
        }

        return TreeResult("", emptyList(), emptyList())
    }

    private fun runOcr(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val lines = result.textBlocks.flatMap { it.lines }
                    .mapNotNull { line ->
                        val t = line.text.trim()
                        val b = line.boundingBox ?: return@mapNotNull null
                        if (t.isBlank()) null else t to b
                    }
                    .sortedBy { it.second.top }

                val options = findOptions(lines, bitmap.width, bitmap.height)
                if (options.size >= 4) {
                    val optionLines = options.take(4)
                    val firstTop = optionLines.first().second.top
                    val question = lines.filter { it.second.bottom < firstTop }
                        .map { it.first }
                        .joinToString(" ")
                    val fp = question + "|" + optionLines.joinToString("|") { it.first }
                    if (fp != lastFingerprint) {
                        lastFingerprint = fp
                        scope.launch {
                            val key = getPrefs("key")
                            val answer = GeminiClient.answerText(
                                key,
                                getPrefs("model", "gemini-2.5-flash-lite"),
                                question,
                                optionLines.map { it.first }
                            )
                            withContext(Dispatchers.Main) {
                                if (answer in 0..3) {
                                    val r = optionLines[answer].second
                                    showTick(Rect(r))
                                }
                                busy.set(false)
                            }
                        }
                    } else {
                        busy.set(false)
                    }
                } else {
                    // Vision fallback for unusual/image-heavy questions.
                    scope.launch {
                        val key = getPrefs("key")
                        val answer = GeminiClient.answerImage(
                            key,
                            getPrefs("model", "gemini-2.5-flash-lite"),
                            bitmap
                        )
                        withContext(Dispatchers.Main) {
                            if (answer in 0..3 && options.size >= 4) {
                                showTick(Rect(options[answer].second))
                            }
                            busy.set(false)
                        }
                    }
                }
            }
            .addOnFailureListener { busy.set(false) }
            .addOnCompleteListener { recognizer.close() }
    }

    private fun findOptions(
        lines: List<Pair<String, Rect>>,
        width: Int,
        height: Int
    ): List<Pair<String, Rect>> {
        val labeled = lines.filter {
            Regex("""^\s*(?:[A-Da-d][\.\)\-:]\s*|\d[\.\)\-:]\s*)""").containsMatchIn(it.first)
        }.take(4)
        if (labeled.size == 4) return labeled

        // Screenshot sample has four wide buttons. Use lower-screen, vertically spaced lines.
        val candidates = lines.filter { (_, r) ->
            r.width() > width * 0.25 && r.height() >= 20 && r.top > height * 0.42
        }.sortedBy { it.second.top }

        if (candidates.size >= 4) {
            val selected = candidates.takeLast(4)
            val gaps = selected.zipWithNext().map { it.second.top - it.first.bottom }
            if (gaps.all { it >= -20 }) return selected
        }
        return emptyList()
    }

    private fun showTick(bounds: Rect) {
        removeTick()
        val tv = TextView(this).apply {
            text = "✓"
            textSize = 32f
            setTextColor(Color.rgb(0, 210, 90))
            setShadowLayer(5f, 0f, 1f, Color.BLACK)
            gravity = Gravity.CENTER
        }

        val size = 58
        val x = max(0, bounds.right - size - 12)
        val y = max(0, bounds.centerY() - size / 2)

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            this.x = x
            this.y = y
        }

        try {
            windowManager?.addView(tv, params)
            tickView = tv
            tickParams = params
        } catch (_: Throwable) {}
    }

    private fun removeTick() {
        val v = tickView ?: return
        try { windowManager?.removeView(v) } catch (_: Throwable) {}
        tickView = null
        tickParams = null
    }

    private fun getPrefs(name: String, default: String = ""): String {
        return getSharedPreferences("quiztick", MODE_PRIVATE).getString(name, default) ?: default
    }
}

private object GeminiClient {
    private val client = OkHttpClient.Builder().build()

    suspend fun answerText(
        apiKey: String,
        model: String,
        question: String,
        options: List<String>
    ): Int = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || options.size < 4) return@withContext -1

        val prompt = """
You are a high-speed multiple-choice quiz solver.
The question can be from ANY field: history, geography, science, physics, chemistry, biology, mathematics, language, vocabulary, literature, discoveries, inventions, technology, sports, culture, religion, geography, current/general knowledge, or any other factual subject. The target quiz commonly shows one question followed by four large vertically stacked choices A-D.
Choose the single best correct option using reliable knowledge and careful reasoning.
Return ONLY one character: A, B, C, or D. No explanation.

QUESTION:
$question

OPTIONS:
A. ${options[0]}
B. ${options[1]}
C. ${options[2]}
D. ${options[3]}
""".trimIndent()

        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("maxOutputTokens", 2)
            })
        }

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return@withContext -1
                val text = response.body?.string().orEmpty()
                val root = JSONObject(text)
                val out = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()
                    .uppercase()
                when {
                    out.startsWith("A") -> 0
                    out.startsWith("B") -> 1
                    out.startsWith("C") -> 2
                    out.startsWith("D") -> 3
                    else -> -1
                }
            }
        } catch (_: Throwable) { -1 }
    }

    suspend fun answerImage(
        apiKey: String,
        model: String,
        bitmap: Bitmap
    ): Int = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext -1
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos)
        val base64 = android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)

        val prompt = """
You are a high-speed multiple-choice quiz solver.
The screenshot contains a quiz question with four answer choices.
The topic may be ANY field.
Identify the question and all four choices from the image, reason carefully, and select the single best answer.
Return ONLY one character: A, B, C, or D. No explanation.
""".trimIndent()

        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", base64)))
            )))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0)
                put("maxOutputTokens", 2)
            })
        }

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return@withContext -1
                val root = JSONObject(response.body?.string().orEmpty())
                val out = root.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text").trim().uppercase()
                when {
                    out.startsWith("A") -> 0
                    out.startsWith("B") -> 1
                    out.startsWith("C") -> 2
                    out.startsWith("D") -> 3
                    else -> -1
                }
            }
        } catch (_: Throwable) { -1 }
    }
}
