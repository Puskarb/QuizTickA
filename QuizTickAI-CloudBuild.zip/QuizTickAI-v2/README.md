# Quiz Tick AI

A minimal Android prototype for fast quiz games.

## What it does

- Runs as an Android Accessibility Service.
- Tries the accessibility tree first for low latency.
- Falls back to an on-device ML Kit OCR screenshot.
- Detects four MCQ choices.
- Sends the question/options to a configurable Gemini model.
- Supports arbitrary quiz subjects rather than only English.
- Places only a green `✓` beside the selected option.
- Uses a vision fallback for image-heavy questions.

## Current limitations

This is a prototype, not a finished Play Store app.

1. The quiz app must allow accessibility/screenshot capture. Secure windows can block screenshots.
2. OCR/layout heuristics are tuned for the sample style and common A-D MCQs.
3. If a quiz uses unusual layouts, answer buttons may need another detector.
4. Network latency and model latency determine the final answer speed.
5. The API key is stored locally in SharedPreferences. Do not distribute your personal API key inside an APK.

## Setup

1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build and install the debug APK.
4. Open Quiz Tick AI.
5. Enter your Gemini API key.
6. Keep model as `gemini-2.5-flash-lite` for low latency, or change it if you have a different model available.
7. Tap **Save settings**.
8. Tap **Open Accessibility settings** and enable Quiz Tick AI.
9. Open the quiz.
10. The service automatically scans screen changes and attempts to place a green tick.

## Recommended next upgrades

- Add a draggable horizontal offset for the tick.
- Add a confidence threshold and a small yellow `?` when uncertain.
- Cache repeated questions.
- Add an optional local OCR-only mode.
- Add a selectable quiz-app package filter to avoid scanning unrelated apps.
- Improve answer-button detection using color/shape/position analysis.
- Add a configurable scan interval.
- Add optional "tap the answer automatically" mode only if the user explicitly wants it.


## Tuned for the supplied real quiz screenshots

The detector is tuned for the portrait layout shown in the supplied screenshots: dark background, centered question card, four large blue answer buttons stacked vertically, centered answer text, and A/B/C/D labels. The AI remains subject-independent.
